package com.a221003.ngnelson.lab5

import android.app.Application
import com.a221003.ngnelson.lab5.data.OrderRepository
import com.a221003.ngnelson.lab5.data.local.OrderDatabase

class CupcakeApplication : Application() {
    val database: OrderDatabase by lazy { OrderDatabase.getDatabase(this) }
    val repository: OrderRepository by lazy { OrderRepository(database.orderDao()) }
}
