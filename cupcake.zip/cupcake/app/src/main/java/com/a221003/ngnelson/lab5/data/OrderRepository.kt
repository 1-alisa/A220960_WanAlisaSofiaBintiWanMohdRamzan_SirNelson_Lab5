package com.a221003.ngnelson.lab5.data

import com.a221003.ngnelson.lab5.data.local.OrderDao
import com.a221003.ngnelson.lab5.data.local.OrderEntity
import kotlinx.coroutines.flow.Flow

class OrderRepository(private val orderDao: OrderDao) {
    val allOrders: Flow<List<OrderEntity>> = orderDao.getAllOrders()

    suspend fun insert(order: OrderEntity) {
        orderDao.insert(order)
    }
}
